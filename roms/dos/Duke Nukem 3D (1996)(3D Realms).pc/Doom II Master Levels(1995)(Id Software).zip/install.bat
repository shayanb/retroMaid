@echo off
DEICE.EXE
if ERRORLEVEL == 1 GOTO END
MASTER.EXE
if ERRORLEVEL == 1 GOTO ERROR
DEL MASTER.EXE
@mkdir wads
@copy attack.* wads
@copy blacktwr.* wads
@copy bloodsea.* wads
@copy canyon.* wads
@copy catwalk.* wads
@copy combine.* wads
@copy fistula.* wads
@copy garrison.* wads
@copy geryon.* wads
@copy manor.* wads
@copy mephisto.* wads
@copy minos.* wads
@copy nessus.* wads
@copy paradox.* wads
@copy subspace.* wads
@copy subterra.* wads
@copy teeth.* wads
@copy ttrap.* wads
@copy vesperas.* wads
@copy virgil.* wads

@del attack.* 
@del blacktwr.* 
@del bloodsea.* 
@del canyon.* 
@del catwalk.* 
@del combine.* 
@del fistula.* 
@del garrison.* 
@del geryon.* 
@del manor.* 
@del mephisto.* 
@del minos.* 
@del nessus.* 
@del paradox.* 
@del subspace.* 
@del subterra.* 
@del teeth.* 
@del ttrap.* 
@del vesperas.* 
@del virgil.* 

doomit doom2

goto END
:ERROR
echo Error installing MASTER.EXE!
:END

